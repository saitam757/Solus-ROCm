See docs/NewLLD.rst
